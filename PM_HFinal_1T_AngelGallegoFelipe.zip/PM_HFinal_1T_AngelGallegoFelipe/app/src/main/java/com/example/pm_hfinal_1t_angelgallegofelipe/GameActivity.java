package com.example.pm_hfinal_1t_angelgallegofelipe;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {

    private int tapCount = 0;
    private TextView tapCounterTextView;
    private Button tapButton;
    private DatabaseHelper databaseHelper;
    private String username;

    // Define levels and their thresholds
    private int[] levelThresholds = {10, 20, 30, 40, 50};
    private int currentLevel = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        databaseHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("username");

        if (username == null || username.isEmpty()) {
            finish();
            return;
        }

        tapCounterTextView = findViewById(R.id.tap_counter);
        tapButton = findViewById(R.id.tap_button);
        Button endGameButton = findViewById(R.id.end_game_button);
        Button resetScoreButton = findViewById(R.id.reset_score_button);

        tapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tapCount++;
                tapCounterTextView.setText(String.valueOf(tapCount));
                checkLevel();
            }
        });

        endGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.addScore(username, tapCount);
                Intent intent = new Intent(GameActivity.this, ScoreActivity.class);
                startActivity(intent);
                finish();
            }
        });

        resetScoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tapCount = 0;
                tapCounterTextView.setText(String.valueOf(tapCount));
                currentLevel = 0;
                tapButton.setBackgroundColor(Color.LTGRAY); // Reset button color
            }
        });
    }

    private void checkLevel() {
        if (currentLevel < levelThresholds.length && tapCount >= levelThresholds[currentLevel]) {
            currentLevel++;
            updateButtonColor();
        }
    }

    private void updateButtonColor() {
        String levelMessage = "Level " + currentLevel;
        switch (currentLevel) {
            case 1:
                tapButton.setBackgroundColor(Color.YELLOW);
                Toast.makeText(this, levelMessage, Toast.LENGTH_SHORT).show();
                break;
            case 2:
                tapButton.setBackgroundColor(Color.GREEN);
                Toast.makeText(this, levelMessage, Toast.LENGTH_SHORT).show();
                break;
            case 3:
                tapButton.setBackgroundColor(Color.BLUE);
                Toast.makeText(this, levelMessage, Toast.LENGTH_SHORT).show();
                break;
            case 4:
                tapButton.setBackgroundColor(Color.MAGENTA);
                Toast.makeText(this, levelMessage, Toast.LENGTH_SHORT).show();
                break;
            case 5:
                tapButton.setBackgroundColor(Color.RED);
                Toast.makeText(this, levelMessage, Toast.LENGTH_SHORT).show();
                break;
            default:
                tapButton.setBackgroundColor(Color.LTGRAY);
                break;
        }
    }
}