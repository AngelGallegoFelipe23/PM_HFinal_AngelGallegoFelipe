package com.example.pm_hfinal_1t_angelgallegofelipe;

import android.content.Context;
import org.json.JSONObject;
import java.io.InputStream;

public class ApiConnector {

    public static JSONObject getLocalData(Context context, String fileName) {
        String json = null;
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
        try {
            return new JSONObject(json);
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}