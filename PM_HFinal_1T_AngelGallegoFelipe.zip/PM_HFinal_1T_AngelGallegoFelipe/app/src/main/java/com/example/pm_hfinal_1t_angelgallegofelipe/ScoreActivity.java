package com.example.pm_hfinal_1t_angelgallegofelipe;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ScoreActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        databaseHelper = new DatabaseHelper(this);

        ListView scoreListView = findViewById(R.id.score_list);
        ArrayList<String> scores = databaseHelper.getAllScores();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, scores);
        scoreListView.setAdapter(adapter);

        Button resetScoreButton = findViewById(R.id.reset_score_button);
        resetScoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.deleteAllScores();
                scores.clear();
                adapter.notifyDataSetChanged();
            }
        });
    }
}